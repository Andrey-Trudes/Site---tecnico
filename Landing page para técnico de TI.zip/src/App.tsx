import { FormEvent, ReactNode, useEffect, useState } from 'react'

const siteConfig = {
  brand: 'Seu setup, elevado ao próximo nível',
  technician: 'Dimitri',
  whatsapp: '5511951469997',
  whatsappLabel: '(11) 95146-9997',
  instagram: 'dimitri_leonar',
}

const photos = {
  laptop: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=2200&q=85',
  repair: 'https://images.unsplash.com/photo-1721332154191-ba5f1534266e?auto=format&fit=crop&w=1000&q=85',
  pc: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1000&q=85',
  board: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=85',
  setup: 'https://images.unsplash.com/photo-1626218174358-7769486c4b79?auto=format&fit=crop&w=1000&q=85',
  processor: 'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?auto=format&fit=crop&w=2200&q=85',
}

const services = [
  {
    icon: 'cpu',
    title: 'Montagem de computadores',
    text: 'Montagem, configuração e organização dos componentes, com atenção às necessidades do seu setup.',
  },
  {
    icon: 'spark',
    title: 'Limpeza de computadores',
    text: 'Higienização interna e externa para remoção de poeira e resíduos.',
  },
  {
    icon: 'game',
    title: 'Limpeza de consoles',
    text: 'Manutenção preventiva e limpeza interna para cuidar do seu equipamento.',
  },
  {
    icon: 'temp',
    title: 'Troca de pasta térmica',
    text: 'Substituição da pasta térmica para melhorar a dissipação de calor e contribuir para o controle da temperatura.',
  },
]

const prices = {
  pc: [
    ['Limpeza interna de PC', 'R$ 100'],
    ['Limpeza + backup', 'R$ 150'],
    ['Limpeza + formatação + backup', 'R$ 180'],
    ['Limpeza + formatação + Windows atualizado + backup', 'R$ 220'],
    ['Montagem de PC', 'Sob consulta'],
  ],
  console: [
    ['Limpeza + pasta térmica — PS3', 'R$ 100'],
    ['Limpeza + pasta térmica — PS4', 'R$ 120'],
    ['Limpeza + pasta térmica — Xbox 360', 'R$ 100'],
    ['Limpeza + pasta térmica — Xbox One', 'R$ 120'],
    ['Limpeza interna — PS5', 'R$ 100'],
    ['Limpeza + pasta térmica — Xbox Series S/X', 'R$ 120'],
  ],
}

function Icon({ name, className = '' }: { name: string; className?: string }) {
  const paths: Record<string, ReactNode> = {
    gpu: <><path d="M2 5v14m0-12h18a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2m4 0v3h10v-3m-7 0v3m4-3v3"/><circle cx="8" cy="12" r="3"/><circle cx="16" cy="12" r="3"/><path d="m7 10 2 4m-3-1 4-2m5-1 2 4m-3-1 4-2"/></>,
    cpu: <><rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v4m6-4v4M9 18v4m6-4v4M2 9h4m-4 6h4m12-6h4m-4 6h4"/></>,
    spark: <><path d="m12 3-1.5 5.5L5 10l5.5 1.5L12 17l1.5-5.5L19 10l-5.5-1.5L12 3Z"/><path d="m5 17-.7 2.3L2 20l2.3.7L5 23l.7-2.3L8 20l-2.3-.7L5 17Z"/></>,
    game: <><path d="M8.5 7h7a5.5 5.5 0 0 1 5.2 7.3l-1.1 3.2a2.2 2.2 0 0 1-3.6.9L14.5 17h-5l-1.6 1.5a2.2 2.2 0 0 1-3.6-.9l-1-3.3A5.5 5.5 0 0 1 8.5 7Z"/><path d="M7 11v4m-2-2h4m7-1h.01M18 14h.01"/></>,
    temp: <><path d="M14 14.8V5a4 4 0 0 0-8 0v9.8a6 6 0 1 0 8 0Z"/><path d="M10 7v10"/></>,
    arrow: <path d="m9 18 6-6-6-6"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    up: <path d="m18 15-6-6-6 6"/>,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/></>,
    whatsapp: <><path d="M20 11.5a8 8 0 0 1-11.7 7.1L4 20l1.4-4.1A8 8 0 1 1 20 11.5Z"/><path d="M8.5 8.2c.5 3 2.3 4.8 5.3 5.3"/></>,
  }
  return <svg aria-hidden="true" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}

function ButtonLink({ href, children, secondary = false, onClick }: { href: string; children: ReactNode; secondary?: boolean; onClick?: () => void }) {
  return <a onClick={onClick} href={href} className={`button ${secondary ? 'button-secondary' : ''}`}>{children}<Icon name="arrow" /></a>
}

function SectionHeading({ eyebrow, title, text }: { eyebrow: string; title: string; text?: string }) {
  return <div className="section-heading"><span>{eyebrow}</span><h2>{title}</h2>{text && <p>{text}</p>}</div>
}

function Header() {
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)
  return <header className="header">
    <a className="brand" href="#top" aria-label={`${siteConfig.brand} — início`}><span className="brand-mark"><Icon name="gpu" /></span><span>{siteConfig.brand}</span></a>
    <button className="menu-button" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? 'Fechar menu' : 'Abrir menu'}><Icon name={open ? 'close' : 'menu'} /></button>
    <nav className={open ? 'nav nav-open' : 'nav'} aria-label="Navegação principal">
      <a href="#servicos" onClick={close}>Serviços</a><a href="#sobre" onClick={close}>Sobre o técnico</a><a href="#processo" onClick={close}>Como funciona</a><a href="#contato" onClick={close}>Contato</a>
      <a className="nav-cta" href="#contato" onClick={close}>Solicitar orçamento</a>
    </nav>
  </header>
}

function Hero() {
  const [active, setActive] = useState(0)
  const slides = [
    { src: photos.laptop, label: 'Notebooks', alt: 'Notebook em um ambiente escuro' },
    { src: photos.pc, label: 'PCs gamers', alt: 'Interior de um PC gamer com componentes iluminados' },
    { src: photos.processor, label: 'Processadores', alt: 'Processador instalado na placa-mãe' },
    { src: 'https://images.unsplash.com/photo-1494083306499-e22e4a457632?auto=format&fit=crop&w=2200&q=85', label: 'Processadores', alt: 'Processador segurado por pinça' },
    { src: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=2200&q=85', label: 'Placas de vídeo', alt: 'Placa de vídeo com coolers' },
    { src: 'https://images.unsplash.com/photo-1696710257827-75e2e5954059?auto=format&fit=crop&w=2200&q=85', label: 'PCs gamers', alt: 'Setup gamer com gabinete iluminado' },
    { src: 'https://images.unsplash.com/photo-1782330301441-5a91d1cc1cd0?auto=format&fit=crop&w=2200&q=85', label: 'Processadores', alt: 'Chip iluminado em placa de circuito' },
    { src: 'https://images.unsplash.com/photo-1621164071312-67bb68821b3f?auto=format&fit=crop&w=2200&q=85', label: 'Placas de vídeo', alt: 'Detalhe do cooler de uma placa de vídeo' },
  ]
  useEffect(() => {
    const timer = window.setInterval(() => setActive(current => (current + 1) % slides.length), 5000)
    return () => window.clearInterval(timer)
  }, [slides.length])
  return <section className="hero" id="top" aria-label="Notebooks, PCs gamers e processadores">
    {slides.map((slide, index) => <img key={slide.src} className={`hero-photo hero-carousel-photo ${index === active ? 'hero-photo-active' : ''}`} src={slide.src} alt={slide.alt} aria-hidden={index !== active} fetchPriority={index === 0 ? 'high' : 'auto'} loading={index === 0 ? 'eager' : 'lazy'}/>)}
    <div className="hero-copy">
      <div className="status"><span /> PCs · Notebooks · Consoles</div>
      <h1>Tecnologia de ponta para o seu <em>equipamento.</em></h1>
      <p className="hero-lead">Manutenção especializada, limpeza e cuidado para preservar o desempenho dos seus computadores e consoles.</p>
      <p className="hero-detail">Montagem, limpeza e manutenção preventiva com atenção aos detalhes e atendimento personalizado.</p>
      <div className="hero-actions"><ButtonLink href="#contato">Solicitar orçamento</ButtonLink><ButtonLink href="#servicos" secondary>Conhecer os serviços</ButtonLink></div>
    </div>
    <div className="hero-caption"><span>TECNOLOGIA BEM CUIDADA.</span><p>Mais atenção aos detalhes.<br/>Mais cuidado com o que é seu.</p></div>
  </section>
}

function Services({ selected, toggleService }: { selected: string[]; toggleService: (value: string) => void }) {
  const [active, setActive] = useState(0)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const move = (direction: number) => setActive(current => (current + direction + services.length) % services.length)
  return <section className="section" id="servicos"><SectionHeading eyebrow="Especialidades" title="Cuidado técnico em cada detalhe." text="Soluções para preservar seus equipamentos, com processo claro e atenção ao seu setup."/>
    <div className="service-carousel" role="region" aria-roledescription="carrossel" aria-label="Serviços de manutenção">
    <div className="carousel-toolbar"><span aria-live="polite">0{active + 1} <small>/ 0{services.length}</small></span><div><button type="button" onClick={() => move(-1)} aria-label="Serviço anterior"><Icon name="arrow" className="previous-arrow"/></button><button type="button" onClick={() => move(1)} aria-label="Próximo serviço"><Icon name="arrow"/></button></div></div>
    <div onTouchStart={e => setTouchStart(e.changedTouches[0].clientX)} onTouchEnd={e => { if (touchStart !== null) { const delta = touchStart - e.changedTouches[0].clientX; if (Math.abs(delta) > 50) move(delta > 0 ? 1 : -1) } setTouchStart(null) }}>
    {services.map((service, index) => <article hidden={index !== active} className={`service-card carousel-slide ${index !== active ? 'slide-hidden' : ''}`} key={service.title} role="group" aria-roledescription="slide" aria-label={`${index + 1} de ${services.length}: ${service.title}`}>
      <div className="service-image"><img loading="lazy" src={[photos.pc, photos.repair, photos.setup, photos.board][index]} alt={['Interior de um computador — imagem ilustrativa', 'Manutenção em componentes eletrônicos — imagem ilustrativa', 'Setup de computador — imagem ilustrativa', 'Detalhe de placa eletrônica — imagem ilustrativa'][index]}/><span>0{index + 1}</span></div>
      <div className="service-content"><div className="service-category"><Icon name={service.icon}/><span>{['MONTAGEM', 'MANUTENÇÃO', 'CONSOLES', 'CUIDADO TÉRMICO'][index]}</span></div><h3>{service.title}</h3><p>{service.text}</p>
      <div className="service-bottom"><strong>{['Sob consulta', 'A partir de R$ 100', 'A partir de R$ 100', 'Sob consulta'][index]}</strong><button className="add-service" type="button" aria-pressed={selected.includes(service.title)} onClick={() => toggleService(service.title)}>{selected.includes(service.title) ? 'Adicionado ao pedido' : 'Adicionar ao pedido'}<Icon name={selected.includes(service.title) ? 'check' : 'arrow'}/></button></div></div>
    </article>)}</div>
    <div className="carousel-footer"><div className="carousel-dots">{services.map((service, i) => <button key={service.title} type="button" aria-label={`Ver ${service.title.toLowerCase()}`} aria-current={i === active ? 'true' : undefined} onClick={() => setActive(i)}/>)}</div><a href="#contato" className="order-link">Ver meu pedido ({selected.length}) <Icon name="arrow"/></a></div></div>
  </section>
}

function Pricing({ selected, toggleService }: { selected: string[]; toggleService: (value: string) => void }) {
  return <section className="section pricing"><SectionHeading eyebrow="Valores" title="Serviços com preços transparentes." text="Valores informados pelo técnico. A necessidade do equipamento é confirmada na avaliação."/>
    <div className="price-grid">
      {[['Computadores', prices.pc], ['Consoles', prices.console]].map(([title, list]) => <div className="price-card" key={title as string}><div className="price-photo"><img loading="lazy" src={title === 'Computadores' ? photos.repair : photos.board} alt={title === 'Computadores' ? 'Intervenção em hardware — fotografia ilustrativa' : 'Componentes eletrônicos — fotografia ilustrativa'}/><div className="price-title"><Icon name={title === 'Computadores' ? 'cpu' : 'game'}/><h3>{title as string}</h3><span>TABELA DE SERVIÇOS</span></div></div>
        <div className="price-content">
        <div>{(list as string[][]).map(([name, price]) => <div className="price-row" key={name}><span>{name}</span><strong>{price}</strong><button className="price-add" type="button" aria-pressed={selected.includes(name)} aria-label={`${selected.includes(name) ? 'Remover' : 'Adicionar'} ${name}`} onClick={() => toggleService(name)}>{selected.includes(name) ? <Icon name="check"/> : '+'}</button></div>)}</div>
        {title === 'Computadores' && <small>* Troca de pasta térmica incluída nas limpezas.</small>}
        <a className="price-link" href="#contato">Solicitar orçamento <Icon name="arrow"/></a></div>
      </div>)}
    </div>
  </section>
}

function About() {
  const highlights = ['1 ano de experiência em TI', 'Experiência em suporte ao cliente', 'Atendimento personalizado', 'Foco em manutenção preventiva']
  return <section className="section about" id="sobre"><div className="about-panel"><div><SectionHeading eyebrow="Sobre o técnico" title={`Cuidado técnico, conversa direta.`}/>
    <p>Atuo há 1 ano na área de Tecnologia da Informação, com experiência em suporte ao cliente na Guerra Tech Solutions. Nesse período, desenvolvi conhecimentos em atendimento, diagnóstico e resolução de problemas relacionados à área de TI.</p>
    <p>Ofereço serviços de manutenção preventiva para computadores e consoles, com foco em preservar o desempenho, prolongar a vida útil dos componentes e reduzir o risco de falhas.</p>
    <div className="experience-note">Experiência profissional <strong>Guerra Tech Solutions</strong></div></div>
    <div><img className="about-photo" loading="lazy" src={photos.board} alt="Detalhes de componentes de hardware — imagem ilustrativa"/><div className="highlight-list">{highlights.map((item, i) => <div key={item}><span>0{i + 1}</span><p>{item}</p><Icon name="check"/></div>)}</div></div></div>
    <div className="qualifications"><span>Formação & qualificações</span><div><Icon name="cpu"/><p><strong>Curso de Hardware</strong><small>Alura</small></p></div><div><Icon name="cpu"/><p><strong>Curso de Redes</strong><small>Alura — Onboarding</small></p></div></div>
  </section>
}

function Process() {
  const steps = [['01', 'Conte o que precisa', 'Informe o equipamento e o serviço desejado.'], ['02', 'Combine os detalhes', 'Alinhe avaliação, orçamento e prazo com o técnico.'], ['03', 'Realização do serviço', 'Após aprovação, o equipamento recebe o cuidado combinado.']]
  return <section className="section" id="processo"><SectionHeading eyebrow="Como funciona" title="Simples do primeiro contato ao cuidado final."/><div className="steps">{steps.map(([n,t,d]) => <article key={n}><span>{n}</span><div><h3>{t}</h3><p>{d}</p></div></article>)}</div></section>
}

function Contact({ selected, toggleService }: { selected: string[]; toggleService: (v: string) => void }) {
  const [model, setModel] = useState('')
  const [details, setDetails] = useState('')
  const [error, setError] = useState('')
  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!selected.length) { setError('Adicione pelo menos um serviço ao pedido.'); return }
    setError('')
    const message = `Olá, ${siteConfig.technician}! Gostaria de solicitar um orçamento.\n\nServiços do meu pedido:\n${selected.map(item => `• ${item}`).join('\n')}\n\nEquipamento: ${model}${details ? `\nDetalhes: ${details}` : ''}`
    window.open(`https://wa.me/${siteConfig.whatsapp}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }
  return <section className="contact section" id="contato"><div className="contact-copy"><span className="eyebrow">Contato & orçamento</span><h2>Seu próximo upgrade começa com <em>cuidado.</em></h2><p>Preserve o desempenho e a durabilidade do seu equipamento com manutenção preventiva e atendimento personalizado. Solicite um orçamento!</p>
    <div className="direct-links"><a href={`https://wa.me/${siteConfig.whatsapp}`} target="_blank" rel="noreferrer"><Icon name="whatsapp"/><span>WhatsApp<small>{siteConfig.whatsappLabel}</small></span></a><a href={`https://instagram.com/${siteConfig.instagram}`} target="_blank" rel="noreferrer"><Icon name="instagram"/><span>Instagram<small>@{siteConfig.instagram}</small></span></a></div></div>
    <form onSubmit={submit}><label>Adicionar serviço ao pedido<select value="" onChange={e => { if (e.target.value && !selected.includes(e.target.value)) toggleService(e.target.value) }}><option value="">Escolha um ou mais serviços</option>{[...services.map(s => s.title), ...prices.pc.map(([name]) => name), ...prices.console.map(([name]) => name), 'Outro serviço / avaliação'].map(name => <option key={name} disabled={selected.includes(name)}>{name}</option>)}</select></label>
      <div className="order-summary"><h3>Meu pedido <span>{selected.length} serviço(s)</span></h3>{selected.length ? <ul>{selected.map(item => <li key={item}><span>{item}</span><button type="button" onClick={() => toggleService(item)} aria-label={`Remover ${item}`}><Icon name="close"/></button></li>)}</ul> : <p>Nenhum serviço adicionado. Escolha acima ou nos cards.</p>}</div>
      {error && <p role="alert" className="order-error">{error}</p>}
      <label>Tipo e modelo do equipamento<input required value={model} onChange={e => setModel(e.target.value)} placeholder="Ex.: notebook Dell Inspiron 15"/></label>
      <label>Descrição da necessidade <small>Opcional</small><textarea value={details} onChange={e => setDetails(e.target.value)} placeholder="Conte brevemente o que está acontecendo..." rows={4}/></label>
      <button className="submit" type="submit"><Icon name="whatsapp"/>Solicitar orçamento pelo WhatsApp<Icon name="arrow"/></button>
      <p className="form-note">Você revisará e enviará a mensagem diretamente no WhatsApp.</p>
    </form>
  </section>
}

function FAQ() {
  const items = [
    ['Quais serviços são oferecidos?', 'Montagem e limpeza de computadores, limpeza de consoles, troca de pasta térmica, backup e formatação conforme a necessidade do equipamento.'],
    ['Como solicitar um orçamento?', 'Preencha o formulário com o serviço e o modelo do equipamento. O botão abrirá o WhatsApp com sua mensagem pronta para você revisar e enviar.'],
    ['Qual é o prazo do serviço?', 'O prazo depende da avaliação, do serviço necessário e das condições do equipamento. Os detalhes são alinhados diretamente com o técnico.'],
    ['A manutenção preventiva garante aumento de desempenho?', 'Não. Os resultados variam conforme as condições de cada equipamento. A manutenção preventiva busca preservar o funcionamento, controlar temperaturas e reduzir riscos de falhas, sem prometer ganho garantido de desempenho.'],
  ]
  return <section className="section faq"><SectionHeading eyebrow="Dúvidas frequentes" title="Antes de enviar seu equipamento."/><div className="faq-list">{items.map(([q,a]) => <details key={q}><summary>{q}<span>+</span></summary><p>{a}</p></details>)}</div></section>
}

function App() {
  const [selectedServices, setSelectedServices] = useState<string[]>([])
  const toggleService = (value: string) => setSelectedServices(current => current.includes(value) ? current.filter(item => item !== value) : [...current, value])
  return <><Header/><main><Hero/><Services selected={selectedServices} toggleService={toggleService}/><Pricing selected={selectedServices} toggleService={toggleService}/><About/><Process/><Contact selected={selectedServices} toggleService={toggleService}/><FAQ/></main>
    <footer><a className="brand" href="#top"><span className="brand-mark"><Icon name="gpu"/></span><span>{siteConfig.brand}<small>Manutenção de computadores e consoles</small></span></a><div><a href={`https://instagram.com/${siteConfig.instagram}`} target="_blank" rel="noreferrer">Instagram</a><a href="#contato">Contato</a><a href="#top">Voltar ao topo <Icon name="up"/></a></div></footer>
  </>
}

export default App
